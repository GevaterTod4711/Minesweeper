package com.jfabricationgames.minesweeper.window;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class ImagePanel extends JPanel {
	
	private static final long serialVersionUID = -7350636427254133855L;
	
	private int[] imagePosition = new int[] {0, 0};
	
	private BufferedImage image;
	
	protected ImageLoader loader = new ImageLoader();
	
	private boolean center = false;
	private boolean adaptSize = false;
	private boolean removeIfToSmall = false;
	
	public ImagePanel() {
		
	}
	public ImagePanel(String path) {
		image = loader.loadImage("com/jfabricationgames/highscorebuilder/images/" + path);
	}
	public ImagePanel(BufferedImage image) {
		this.image = image;
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (image != null) {
			if (removeIfToSmall && !adaptSize) {
				if (getWidth() < image.getWidth() || getHeight() < image.getHeight()) {
					return;
				}
			}
			if (center) {
				imagePosition[0] = (getWidth() - image.getWidth())/2;
				imagePosition[1] = (getHeight() - image.getHeight())/2;
			}
			if (adaptSize) {
				Graphics2D g2 = (Graphics2D) g;
				int newW = (int) (image.getWidth() * (((double) getWidth()) / image.getWidth()));
				int newH = (int) (image.getHeight() * (((double) getHeight()) / image.getHeight()));
				g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
				g2.drawImage(image, 0, 0, newW, newH, null);
			}
			else {
				g.drawImage(image, imagePosition[0], imagePosition[1], null);				
			}
		}
	}
	
	public void setPreferedSize() {
		setPreferredSize(new Dimension(image.getWidth() + imagePosition[0], image.getHeight() + imagePosition[1]));
	}
	
	public void setCentered(boolean center) {
		this.center = center;
	}
	public void setAdaptSize(boolean adaptSize) {
		this.adaptSize = adaptSize;
	}
	
	protected void setImage(BufferedImage image) {
		this.image = image;
	}
	protected void setImagePosition(int[] imagePosition) throws IllegalArgumentException {
		if (imagePosition.length != 2) {
			throw new IllegalArgumentException("The array imagePosition must have two fields.");
		}
		this.imagePosition = imagePosition;
	}
	
	public boolean isRemoveIfToSmall() {
		return removeIfToSmall;
	}
	public void setRemoveIfToSmall(boolean removeIfToSmall) {
		this.removeIfToSmall = removeIfToSmall;
	}
}