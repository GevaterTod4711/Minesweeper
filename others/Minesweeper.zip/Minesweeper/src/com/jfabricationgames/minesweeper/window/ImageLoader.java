package com.jfabricationgames.minesweeper.window;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;

public class ImageLoader {
	
	public BufferedImage loadImage(File path) {
		try {
			BufferedImage image = ImageIO.read(path);
			return image;
		}
		catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public BufferedImage loadImage(String path) {
		URL url = getClass().getClassLoader().getResource(path);
		try {
			BufferedImage image = ImageIO.read(url);
			return image;
		}
		catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}