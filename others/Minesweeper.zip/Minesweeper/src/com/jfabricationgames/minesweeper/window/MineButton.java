package com.jfabricationgames.minesweeper.window;

import java.awt.Color;
import java.awt.image.BufferedImage;

import javax.swing.border.BevelBorder;

import com.jfabricationgames.minesweeper.game.GameCalculator;

public class MineButton extends ImagePanel {
	
	private static final long serialVersionUID = 5116955849219361878L;
	
	private static final BufferedImage[] images = loadImages();
	
	private boolean mine;
	private boolean opened;
	private boolean marked;
	
	private int minesNearby;
	
	private int x;
	private int y;
	
	private GameCalculator gameCalculator;
	
	public MineButton(int x, int y, GameCalculator gameCalculator) {
		this.x = x;
		this.y = y;
		this.gameCalculator = gameCalculator;
		setAdaptSize(true);
		setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
	}
	
	private static BufferedImage[] loadImages() {
		ImageLoader loader = new ImageLoader();
		BufferedImage[] images = new BufferedImage[11];
		images[0] = new BufferedImage(10, 10, BufferedImage.TYPE_INT_ARGB);
		images[1] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_number_1.png");
		images[2] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_number_2.png");
		images[3] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_number_3.png");
		images[4] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_number_4.png");
		images[5] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_number_5.png");
		images[6] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_number_6.png");
		images[7] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_number_7.png");
		images[8] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_number_8.png");
		images[9] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_mine.png");
		images[10] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_flag.png");
		return images;
	}
	
	public void trigger(GameCalculator gameCalculator) {
		if (mine) {
			gameCalculator.mineTriggered();
			openField(gameCalculator);
		}
		else if (minesNearby > 0) {
			openField(gameCalculator);
		}
		else {
			openField(gameCalculator);
			gameCalculator.openNearby(x, y);
		}
	}
	
	public void openField(GameCalculator gameCalculator) {
		opened = true;
		gameCalculator.fieldOpened();
		setBackground(Color.LIGHT_GRAY);
		setBorder(null);
		if (mine) {
			setImage(images[9]);
		}
		else {
			setImage(images[minesNearby]);
		}
		repaint();
	}
	
	public boolean isMarked() {
		return marked;
	}
	public void setMarked(boolean marked) {
		if (!opened) {
			this.marked = marked;
			if (marked) {
				setImage(images[10]);
				gameCalculator.setFieldsMarked(gameCalculator.getFieldsMarked() + 1);
			}
			else {
				setImage(images[0]);
				gameCalculator.setFieldsMarked(gameCalculator.getFieldsMarked() - 1);
			}
			repaint();
		}
	}
	
	public boolean isOpened() {
		return opened;
	}
	
	public boolean isMine() {
		return mine;
	}
	public void setMine(boolean mine) {
		this.mine = mine;
	}

	public int getMinesNearby() {
		return minesNearby;
	}
	public void setMinesNearby(int minesNearby) {
		this.minesNearby = minesNearby;
	}
	
	public int getXCoordinate() {
		return x;
	}
	public int getYCoordinate() {
		return y;
	}
}