package com.jfabricationgames.minesweeper.window;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import net.miginfocom.swing.MigLayout;

import com.jfabricationgames.highscorebuilder.dbConnection.LoginException;
import com.jfabricationgames.highscorebuilder.dbConnection.NoScoreException;
import com.jfabricationgames.highscorebuilder.display.HighscoreLoginDialog;
import com.jfabricationgames.highscorebuilder.display.HighscoreMenu;
import com.jfabricationgames.highscorebuilder.highscore.HighscoreManager;
import com.jfabricationgames.minesweeper.game.GameCalculator;
import com.jfabricationgames.toolbox.properties.dataView.PropertiesFile;
import com.jfabricationgames.toolbox.properties.event.PropertiesWindowListener;

public class MinesweeperGameFrame extends JFrame {
	
	private static final long serialVersionUID = -8051274972088602367L;

	public static final int ALL_MINES_FOUND = 0;
	public static final int MINE_TRIGGERED = 1;
	
	public static final int IMAGE_NORMAL = 0;
	public static final int IMAGE_BUTTON_PRESSED = 1;
	public static final int IMAGE_WON = 2;
	public static final int IMAGE_LOST = 3;
	
	public static final String HIGHSCORE_TABLE_EASY = "MinesweeperHighscoresD1";
	public static final String HIGHSCORE_TABLE_ADVANCED = "MinesweeperHighscoresD2";
	public static final String HIGHSCORE_TABLE_PROFI = "MinesweeperHighscoresD3";
	
	private GameCalculator gameCalculator = new GameCalculator(this);
	
	private BufferedImage[] images = new BufferedImage[4];
	private BufferedImage[] bananas = new BufferedImage[2];
	private BufferedImage[] potatos = new BufferedImage[2];
	
	private BufferedImage empty = new BufferedImage(10, 10, BufferedImage.TYPE_INT_ARGB);
	
	private JPanel contentPane;
	
	private JMenuBar menuBar;
	private JMenu mnGame;
	private HighscoreMenu menu;
	
	private JRadioButtonMenuItem rdbtnmntmEasy;
	private JRadioButtonMenuItem rdbtnmntmAdvanced;
	private JRadioButtonMenuItem rdbtnmntmProfi;
	
	private ImagePanel imagePanel;
	private ImagePanel panel;
	private ImagePanel panel_2;
	private ImagePanel panel_3;

	private JLabel lblTime;
	private JLabel lblMines;
	
	private MinesweeperMinePanel minePanel;
	
	private PropertiesFile propsFile = new PropertiesFile(this);
	
	private static HighscoreManager highscoreManagerEasy;
	private static HighscoreManager highscoreManagerAdvanced;
	private static HighscoreManager highscoreManagerProfi;
	
	public static void main(final String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					if (args.length == 2) {
						try {
							highscoreManagerEasy = new HighscoreManager(HIGHSCORE_TABLE_EASY, args[0], args[1]);
							highscoreManagerAdvanced = new HighscoreManager(HIGHSCORE_TABLE_ADVANCED, args[0], args[1]);
							highscoreManagerProfi = new HighscoreManager(HIGHSCORE_TABLE_PROFI, args[0], args[1]);
						}
						catch (LoginException le) {
							highscoreManagerEasy = new HighscoreManager(HIGHSCORE_TABLE_EASY);
							highscoreManagerAdvanced = new HighscoreManager(HIGHSCORE_TABLE_ADVANCED);
							highscoreManagerProfi = new HighscoreManager(HIGHSCORE_TABLE_PROFI);
						}
					}
					else {
						highscoreManagerEasy = new HighscoreManager(HIGHSCORE_TABLE_EASY);
						highscoreManagerAdvanced = new HighscoreManager(HIGHSCORE_TABLE_ADVANCED);
						highscoreManagerProfi = new HighscoreManager(HIGHSCORE_TABLE_PROFI);
					}
					MinesweeperGameFrame frame = new MinesweeperGameFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public MinesweeperGameFrame() {
		
		addWindowListener(new PropertiesWindowListener(propsFile, PropertiesWindowListener.WINDOW_CLOSING_EVENT));
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				propsFile.setProperty("difficulty", Integer.toString(getDifficulty()));
				try {
					propsFile.store("");					
				}
				catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		});
		
		final MinesweeperGameFrame selfRef = this;
		
		setResizable(false);
		setTitle("Minesweeper - JFabricationGames");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 645);
		propsFile.alignWindow();
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnGame = new JMenu("Game");
		menuBar.add(mnGame);
		
		rdbtnmntmEasy = new JRadioButtonMenuItem("Easy");
		rdbtnmntmEasy.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startGame();
			}
		});
		rdbtnmntmEasy.setSelected(true);
		mnGame.add(rdbtnmntmEasy);
		
		rdbtnmntmAdvanced = new JRadioButtonMenuItem("Advanced");
		rdbtnmntmAdvanced.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startGame();
			}
		});
		mnGame.add(rdbtnmntmAdvanced);
		
		rdbtnmntmProfi = new JRadioButtonMenuItem("Profi");
		rdbtnmntmProfi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startGame();
			}
		});
		mnGame.add(rdbtnmntmProfi);
		
		ButtonGroup group = new ButtonGroup();
		group.add(rdbtnmntmEasy);
		group.add(rdbtnmntmAdvanced);
		group.add(rdbtnmntmProfi);
		
		menu = new HighscoreMenu(highscoreManagerEasy, this, "Minesweeper");
		menu.setActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (getDifficulty()) {
					case 1:
						highscoreManagerEasy.getHighscoreFrame(selfRef, "Minesweeper - Easy", true).setVisible(true);
						break;
					case 2:
						highscoreManagerAdvanced.getHighscoreFrame(selfRef, "Minesweeper - Advanced", true).setVisible(true);
						break;
					case 3:
						highscoreManagerProfi.getHighscoreFrame(selfRef, "Minesweeper - Profi", true).setVisible(true);
						break;
				}
			}
		}, HighscoreMenu.MENU_ITEM_SHOW_HIGHSCORES);
		menu.setActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				HighscoreLoginDialog dialog = highscoreManagerEasy.showLoginDialog(selfRef);
				while (dialog.isVisible()) {
					try {
						Thread.sleep(100);
					}
					catch (InterruptedException ie) {
						ie.printStackTrace();
					}
				}
				highscoreManagerAdvanced.setUser(highscoreManagerEasy.getUser());
				highscoreManagerProfi.setUser(highscoreManagerEasy.getUser());
			}
		}, HighscoreMenu.MENU_ITEM_LOGIN_TO_JFG);
		menuBar.add(menu);
		
		
		if (propsFile.getProperty("difficulty") != null) {
			switch (Integer.parseInt(propsFile.getProperty("difficulty"))) {
				case 1:
					rdbtnmntmEasy.setSelected(true);
					break;
				case 2:
					rdbtnmntmAdvanced.setSelected(true);
					break;
				case 3:
					rdbtnmntmProfi.setSelected(true);
					break;
			}
		}
		
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[25px,grow][424px,grow][25px,grow]", "[40px:n,grow][110px,grow][502px]"));
		
		loadImages();
		
		panel = new ImagePanel("headline.png");
		panel.setAdaptSize(true);
		contentPane.add(panel, "cell 0 0 3 1,grow");
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.GRAY);
		contentPane.add(panel_1, "cell 0 1 3 1,grow");
		panel_1.setLayout(new MigLayout("", "[grow][100px:n:100px][grow]", "[100px:n:100px,grow,center][30px:n:30px]"));
		
		imagePanel = new ImagePanel();
		imagePanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		imagePanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				startGame();
			}
		});
		
		panel_2 = new ImagePanel();
		panel_2.setBackground(Color.GRAY);
		panel_2.setCentered(true);
		panel_1.add(panel_2, "cell 0 0,grow");
		panel_1.add(imagePanel, "cell 1 0,grow");
		
		panel_3 = new ImagePanel();
		panel_3.setBackground(Color.GRAY);
		panel_3.setCentered(true);
		panel_1.add(panel_3, "cell 2 0,grow");
		
		startGame();
		
		lblMines = new JLabel("Mines: " + (gameCalculator.getMinesOnField() - gameCalculator.getFieldsMarked()));
		panel_1.add(lblMines, "cell 0 1,alignx center");
		
		lblTime = new JLabel("Time: 0");
		panel_1.add(lblTime, "cell 2 1,alignx center");
		
		setImage(IMAGE_NORMAL);
	}
	
	private void loadImages() {
		ImageLoader loader = new ImageLoader();
		images[0] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_normal.png");
		images[1] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_buttonPressed.png");
		images[2] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_won.jpg");
		images[3] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_lost.jpg");
		bananas[0] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_banana1.png");
		bananas[1] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_banana2.png");
		potatos[0] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_potato1.png");
		potatos[1] = loader.loadImage("com/jfabricationgames/minesweeper/images/minesweeper_potato2.png");
	}
	
	public void setImage(int image) {
		if ((gameCalculator.isMineTriggered() && image != IMAGE_LOST) || (gameCalculator.isGameEnded() && !gameCalculator.isMineTriggered() && image != IMAGE_WON)) {
			return;
		}
		imagePanel.setImage(images[image]);
		imagePanel.repaint();
		if (image == IMAGE_WON) {
			panel_2.setImage(bananas[0]);
			panel_3.setImage(bananas[1]);
			panel_2.repaint();
			panel_3.repaint();
		}
		else if (image == IMAGE_LOST) {
			panel_2.setImage(potatos[0]);
			panel_3.setImage(potatos[1]);
			panel_2.repaint();
			panel_3.repaint();
		}
	}
	
	private void startGame() {
		if (minePanel != null) {
			contentPane.remove(minePanel);			
		}
		switch (getDifficulty()) {
			case 1:
				minePanel = new MinesweeperMinePanel(GameCalculator.FIELD_DIMENSION_EASY, this);
				setSize(GameCalculator.FRAME_DIMENSION_EASY);
				break;
			case 2:
				minePanel = new MinesweeperMinePanel(GameCalculator.FIELD_DIMENSION_ADVANCED, this);
				setSize(GameCalculator.FRAME_DIMENSION_ADVANCED);
				break;
			case 3:
				minePanel = new MinesweeperMinePanel(GameCalculator.FIELD_DIMENSION_PROFI, this);
				setSize(GameCalculator.FRAME_DIMENSION_PROFI);
				break;
		}
		minePanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		contentPane.add(minePanel, "cell 1 2,grow");
		gameCalculator.setButtons(minePanel.getButtons());
		gameCalculator.startGame();
		setImage(IMAGE_NORMAL);
		panel_2.setImage(empty);
		panel_3.setImage(empty);
		revalidate();
		repaint();
	}
	
	public void endGame(int state) {
		switch (state) {
			case ALL_MINES_FOUND:
				setImage(IMAGE_WON);
				switch (getDifficulty()) {
					case 1:
						updateScore(highscoreManagerEasy);
						break;
					case 2:
						updateScore(highscoreManagerAdvanced);
						break;
					case 3:
						updateScore(highscoreManagerProfi);
						break;
				}
				gameCalculator.setGameEnded(true);
				break;
			case MINE_TRIGGERED:
				setImage(IMAGE_LOST);
				gameCalculator.setGameEnded(true);
				break;
		}
	}
	
	private void updateScore(HighscoreManager manager) {
		if (manager.getUser() != null) {
			int time = -1;
			int currentHighscore = -1;
			try {
				time = gameCalculator.getTime();
				currentHighscore = manager.getHighscore();
			}
			catch (IllegalArgumentException ie) {
				ie.printStackTrace();
				return;
			}
			catch (NoScoreException nse) {
				currentHighscore = Integer.MAX_VALUE;
			}
			if (currentHighscore > time && time > 0) {
				try {
					manager.updateHighscore(time);
				}
				catch (LoginException le) {
					le.printStackTrace();
				}
			}
		}
	}
	
	public int getDifficulty() {
		if (rdbtnmntmEasy.isSelected()) {
			return 1;
		}
		else if (rdbtnmntmAdvanced.isSelected()) {
			return 2;
		}
		else if (rdbtnmntmProfi.isSelected()) {
			return 3;
		}
		return 0;
	}
	
	public JLabel getLblTime() {
		return lblTime;
	}

	public JLabel getLblMines() {
		return lblMines;
	}
	
	public GameCalculator getGameCalculator() {
		return gameCalculator;
	}
}