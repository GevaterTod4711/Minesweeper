package com.jfabricationgames.minesweeper.window;

import java.awt.Dimension;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JPanel;

import net.miginfocom.swing.MigLayout;

import com.jfabricationgames.minesweeper.game.MineButtonMouseListener;
import java.awt.Color;

public class MinesweeperMinePanel extends JPanel {
	
	private Dimension preferedPanelSize;
	
	private static final long serialVersionUID = 8340823785971366161L;
	
	private Map<String, MineButton> buttons = new HashMap<String, MineButton>();
	
	public MinesweeperMinePanel(Dimension size, MinesweeperGameFrame gameFrame) {
		setBackground(Color.GRAY);
		preferedPanelSize = new Dimension(size.width*40 + 5, size.height*40 + 5);
		setPreferredSize(preferedPanelSize);
		setMaximumSize(preferedPanelSize);
		StringBuilder layout = new StringBuilder();
		String layoutWidth;
		String layoutHeight;
		for (int i = 0; i < size.width; i++) {
			layout.append("[35px:n:35px,fill]");
		}
		layoutWidth = layout.toString();
		layout.setLength(0);
		for (int i = 0; i < size.height; i++) {
			layout.append("[35px:n:35px,fill]");
		}
		layoutHeight = layout.toString();
		setLayout(new MigLayout("", layoutWidth, layoutHeight));
		
		for (int i = 0; i < size.width; i++) {
			for (int j = 0; j < size.height; j++) {
				MineButton button = new MineButton(i, j, gameFrame.getGameCalculator());
				button.addMouseListener(new MineButtonMouseListener(i, j, button, gameFrame));
				add(button, "cell " + i + " " + j + ",grow");
				buttons.put(i + "/" + j, button);
			}
		}
	}
	
	public Dimension getPreferedPanelSize() {
		return preferedPanelSize;
	}
	
	public Map<String, MineButton> getButtons() {
		return buttons;
	}
}