package com.jfabricationgames.minesweeper.game;

import java.awt.Dimension;
import java.util.Map;

import com.jfabricationgames.minesweeper.window.MineButton;
import com.jfabricationgames.minesweeper.window.MinesweeperGameFrame;

public class GameCalculator {
	
	public static final Dimension FIELD_DIMENSION_EASY = new Dimension(10, 10);
	public static final Dimension FIELD_DIMENSION_ADVANCED = new Dimension(20, 10);
	public static final Dimension FIELD_DIMENSION_PROFI = new Dimension(25, 15);
	
	public static final Dimension FRAME_DIMENSION_EASY = new Dimension(450, 675);
	public static final Dimension FRAME_DIMENSION_ADVANCED = new Dimension(850, 675);
	public static final Dimension FRAME_DIMENSION_PROFI = new Dimension(1050, 875);
	
	public static final int MINES_EASY = 10;
	public static final int MINES_ADVANCED = 20;
	public static final int MINES_PROFI = 40;
	
	private int[][] field;
	
	private int fieldsMarked = 0;
	private int fieldsOpened = 0;
	private int minesOnField = 0;
	
	private boolean mineTriggered;
	private boolean gameEnded;
	private boolean gameStarted;
	
	private Map<String, MineButton> buttons;
	
	private MinesweeperGameFrame gameFrame;
	
	private TimerThread timerThread = new TimerThread();
	
	public GameCalculator(MinesweeperGameFrame gameFrame) {
		this.gameFrame = gameFrame;
		timerThread.start();
	}
	
	private class TimerThread extends Thread implements Runnable {
		
		private int time;
		
		private boolean timerRunning;
		
		@Override
		public void run() {
			try {
				while (true) {
					Thread.sleep(1000);
					if (timerRunning) {
						time++;
						gameFrame.getLblTime().setText("Time: " + time);
					}
				}
			}
			catch (InterruptedException ie) {
				
			}
		}
		
		public void reset() {
			timerRunning = false;
			time = 0;
			if (gameFrame.getLblTime() != null) {
				gameFrame.getLblTime().setText("Time: 0");
			}
		}
		
		public int getTime() {
			return time;
		}
		
		public void startTimer() {
			timerRunning = true;
		}
		public void stopTimer() {
			timerRunning = false;
		}
		
		public boolean isTimerRunning() {
			return timerRunning;
		}
	}
	
	public void startGame() {
		mineTriggered = false;
		gameEnded = false;
		gameStarted = true;
		fieldsOpened = 0;
		fieldsMarked = 0;
		timerThread.reset();
		switch (gameFrame.getDifficulty()) {
			case 1:
				field = new int[FIELD_DIMENSION_EASY.width][FIELD_DIMENSION_EASY.height];
				minesOnField = MINES_EASY;
				break;
			case 2:
				field = new int[FIELD_DIMENSION_ADVANCED.width][FIELD_DIMENSION_ADVANCED.height];
				minesOnField = MINES_ADVANCED;
				break;
			case 3:
				field = new int[FIELD_DIMENSION_PROFI.width][FIELD_DIMENSION_PROFI.height];
				minesOnField = MINES_PROFI;
				break;
		}
		int mines = minesOnField;
		int randomX;
		int randomY;
		while (mines > 0) {
			randomX = (int) (Math.random() * field.length);
			randomY = (int) (Math.random() * field[0].length);
			if (field[randomX][randomY] == 0) {
				field[randomX][randomY] = 1;
				buttons.get(randomX + "/" + randomY).setMine(true);
				mines--;
			}
		}
		for (int i = 0; i < field.length; i++) {
			for (int j = 0; j < field[0].length; j++) {
				buttons.get(i + "/" + j).setMinesNearby(getMinesNearby(i, j));
			}
		}
	}
	
	private int getMinesNearby(int x, int y) {
		int mines = 0;
		if (x > 0) {
			if (y > 0 && buttons.get((x-1) + "/" + (y-1)).isMine()) {
				mines++;
			}
			if (buttons.get((x-1) + "/" + y).isMine()) {
				mines++;
			}
			if (y < (field[0].length-1) && buttons.get((x-1) + "/" + (y+1)).isMine()) {
				mines++;
			}
		}
		if (x < (field.length-1)) {
			if (y > 0 && buttons.get((x+1) + "/" + (y-1)).isMine()) {
				mines++;
			}
			if (buttons.get((x+1) + "/" + y).isMine()) {
				mines++;
			}
			if (y < (field[0].length-1) && buttons.get((x+1) + "/" + (y+1)).isMine()) {
				mines++;
			}
		}
		if (y > 0 && buttons.get(x + "/" + (y-1)).isMine()) {
			mines++;
		}
		if (y < (field[0].length-1) && buttons.get(x + "/" + (y+1)).isMine()) {
			mines++;
		}
		return mines;
	}
	
	public void openNearby(int x, int y) {
		MineButton button;
		if (x > 0) {
			if (y > 0) {
				button = buttons.get((x-1) + "/" + (y-1));
				if (button != null && !button.isOpened() && !button.isMarked() && !button.isMine()) {
					button.openField(this);
					if (button.getMinesNearby() == 0) {
						openNearby(x-1, y-1);
					}
				}
			}
			button = buttons.get((x-1) + "/" + y);
			if (button != null && !button.isOpened() && !button.isMarked() && !button.isMine()) {
				button.openField(this);
				if (button.getMinesNearby() == 0) {
					openNearby(x-1, y);
				}
			}
			if (y < (field[0].length-1)) {
				button = buttons.get((x-1) + "/" + (y+1));
				if (button != null && !button.isOpened() && !button.isMarked() && !button.isMine()) {
					button.openField(this);
					if (button.getMinesNearby() == 0) {
						openNearby(x-1, y+1);
					}
				}
			}
		}
		if (x < (field.length-1)) {
			if (y > 0) {
				button = buttons.get((x+1) + "/" + (y-1));
				if (button != null && !button.isOpened() && !button.isMarked() && !button.isMine()) {
					button.openField(this);
					if (button.getMinesNearby() == 0) {
						openNearby(x+1, y-1);
					}
				}
			}
			button = buttons.get((x+1) + "/" + y);
			if (button != null && !button.isOpened() && !button.isMarked() && !button.isMine()) {
				button.openField(this);
				if (button.getMinesNearby() == 0) {
					openNearby(x+1, y);
				}
			}
			if (y < (field[0].length-1)) {
				button = buttons.get((x+1) + "/" + (y+1));
				if (button != null && !button.isOpened() && !button.isMarked() && !button.isMine()) {
					button.openField(this);
					if (button.getMinesNearby() == 0) {
						openNearby(x+1, y+1);
					}
				}
			}
		}
		if (y > 0) {
			button = buttons.get(x + "/" + (y-1));
			if (button != null && !button.isOpened() && !button.isMarked() && !button.isMine()) {
				button.openField(this);
				if (button.getMinesNearby() == 0) {
					openNearby(x, y-1);
				}
			}
		}
		if (y < (field[0].length-1)) {
			button = buttons.get(x + "/" + (y+1));
			if (button != null && !button.isOpened() && !button.isMarked() && !button.isMine()) {
				button.openField(this);
				if (button.getMinesNearby() == 0) {
					openNearby(x, y+1);
				}
			}
		}
	}
	
	public void fieldClicked(int x, int y) {
		if (gameStarted) {
			timerThread.startTimer();
			gameStarted = false;
		}
		MineButton button = buttons.get(x + "/" + y);
		button.trigger(this);
		if (!mineTriggered && fieldsOpened == ((field.length * field[0].length) - minesOnField)) {
			for (MineButton mine : buttons.values()) {
				if (!mine.isOpened() && !mine.isMarked()) {
					mine.setMarked(true);
				}
			}
			timerThread.stopTimer();
			gameFrame.endGame(MinesweeperGameFrame.ALL_MINES_FOUND);
		}
	}
	
	public int getTime() throws IllegalArgumentException {
		if (timerThread.isTimerRunning()) {
			throw new IllegalArgumentException("Timer still running");
		}
		else {
			return timerThread.getTime();
		}
	}
	
	public void fieldOpened() {
		fieldsOpened++;
	}
	
	public boolean isMineTriggered() {
		return mineTriggered;
	}
	
	public int getMinesOnField() {
		return minesOnField;
	}
	
	public int getFieldsMarked() {
		return fieldsMarked;
	}
	public void setFieldsMarked(int fieldsMarked) {
		this.fieldsMarked = fieldsMarked;
		gameFrame.getLblMines().setText("Mines: " + (minesOnField - fieldsMarked));
	}
	public void mineTriggered() {
		mineTriggered = true;
		gameFrame.endGame(MinesweeperGameFrame.MINE_TRIGGERED);
		timerThread.stopTimer();
	}
	
	public boolean isGameEnded() {
		return gameEnded;
	}
	public void setGameEnded(boolean gameEnded) {
		this.gameEnded = gameEnded;
	}
	
	public Map<String, MineButton> getButtons() {
		return buttons;
	}
	public void setButtons(Map<String, MineButton> buttons) {
		this.buttons = buttons;
	}
}