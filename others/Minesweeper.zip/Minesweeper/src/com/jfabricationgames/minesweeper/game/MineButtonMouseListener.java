package com.jfabricationgames.minesweeper.game;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import com.jfabricationgames.minesweeper.window.MineButton;
import com.jfabricationgames.minesweeper.window.MinesweeperGameFrame;

public class MineButtonMouseListener extends MouseAdapter {
	
	private int x;
	private int y;
	
	private long mousePressedTimeStamp;
	
	private MineButton button;
	
	private MinesweeperGameFrame gameFrame;
	
	public MineButtonMouseListener(int x, int y, MineButton button, MinesweeperGameFrame gameFrame) {
		this.x = x;
		this.y = y;
		this.button = button;
		this.gameFrame = gameFrame;
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		if (!gameFrame.getGameCalculator().isGameEnded()) {
			mousePressedTimeStamp = System.currentTimeMillis();
			if (e.getButton() == MouseEvent.BUTTON1) {
				gameFrame.setImage(MinesweeperGameFrame.IMAGE_BUTTON_PRESSED);
			}
		}
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
		if (!gameFrame.getGameCalculator().isGameEnded()) {
			if (System.currentTimeMillis() - mousePressedTimeStamp < 1000) {
				if (!gameFrame.getGameCalculator().isGameEnded()) {
					if (e.getButton() == MouseEvent.BUTTON1 && !button.isMarked() && !button.isOpened()) {
						gameFrame.getGameCalculator().fieldClicked(x, y);
					}
					else if (e.getButton() == MouseEvent.BUTTON3 && !button.isOpened()) {
						button.setMarked(!button.isMarked());
					}
				}
			}
			gameFrame.setImage(MinesweeperGameFrame.IMAGE_NORMAL);
		}
	}
	
	public MineButton getButton() {
		return button;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
}