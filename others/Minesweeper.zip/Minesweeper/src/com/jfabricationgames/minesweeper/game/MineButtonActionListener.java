package com.jfabricationgames.minesweeper.game;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.jfabricationgames.minesweeper.window.MineButton;
import com.jfabricationgames.minesweeper.window.MinesweeperGameFrame;

@Deprecated
public class MineButtonActionListener implements ActionListener {
	
	private int x;
	private int y;
	
	private MineButton button;
	
	private MinesweeperGameFrame gameFrame;

	public MineButtonActionListener(int x, int y, MineButton button, MinesweeperGameFrame gameFrame) {
		this.x = x;
		this.y = y;
		this.button = button;
		this.gameFrame = gameFrame;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		gameFrame.getGameCalculator().fieldClicked(x, y);
	}
	
	public MineButton getButton() {
		return button;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
}